{\rtf1\ansi\ansicpg1252\cocoartf1671\cocoasubrtf200
{\fonttbl\f0\fswiss\fcharset0 Helvetica-Bold;\f1\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;}
{\*\expandedcolortbl;;\cssrgb\c0\c1\c1;}
\margl1440\margr1440\vieww25220\viewh16900\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\b\fs28 \cf2 \ul \ulc2 Aaron Yoon: aaronshii@csu.fullerton.edu\
Gary Kam: Kamgary109@csu.fullerton.edu\cf0 \ulc0 \
\
Programming Language: Java\
\
Steps to Execute:
\f1\b0\fs24 \ulnone \
\
	1) Open 2 terminals to execute the jar files
\f0\b \

\f1\b0 \
	2) Change directories to where the jar files exist\
\
	3) First run the server.jar file (the number at the end can change. This is just the port number to establish a connection)\
\
		i.e.) for OSX terminal: java -jar server.jar 471\
\
	4) Secondly run the client.jar file (with the same port number)\
\
		i.e.) for OSX terminal: java -jar client.jar 471\
\
	5) Once both are opened, on the terminal running the client.jar file, you will be allowed to run 	the following commands\'85\
\
		- get  <filename>	(download files from the server)\
		- put <filename>	(upload files from the client into the server)\
		- ls			(list the files that exist in the server)\
		- quit 			(exits the program)\
\
	6) When using the get or put, make sure that the user includes the file name including the .txt part (i.e. GameOfThrones.txt)\
\
	7) Complete! If you have any questions please email us!\
\
\

\f0\b\fs28 \ul Additional Notes:\
\

\f1\b0\fs24 \ulnone 	- We made a separate folder called \'93server\'94 to show that it is passing the files through\
	- The port is opening and closing every time\
	- We have provided some txt files to demonstrate! Please feel free to use your own .txt files.}