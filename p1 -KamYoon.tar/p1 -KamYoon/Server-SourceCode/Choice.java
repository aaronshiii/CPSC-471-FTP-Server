package ftp;

/**
 * Defines the actions to perform on server.
 */
public enum Choice {
  INVALID,
  GET,
  PUT,
  LS
}
